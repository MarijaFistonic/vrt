var APP_DATA = {
  "scenes": [
    {
      "id": "0-20240417_1743561",
      "name": "20240417_174356(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": -2.031219737311476,
        "pitch": 0,
        "fov": 1.290348174345596
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": -2.9259810260109784,
          "pitch": -0.30867862779529176,
          "title": "Tvrđava Klis<br>",
          "text": "Text"
        },
        {
          "yaw": -0.6643130550717444,
          "pitch": -0.04666240189392212,
          "title": "Split<br>",
          "text": "Text"
        },
        {
          "yaw": -0.382521349631606,
          "pitch": -0.11363935844671857,
          "title": "Marjan<br>",
          "text": "Text"
        },
        {
          "yaw": 0.16498541483982798,
          "pitch": -0.2261674150675148,
          "title": "Kozjak<br>",
          "text": "Text"
        }
      ]
    },
    {
      "id": "1-20240417_174554",
      "name": "20240417_174554",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "2-20240417_1746401",
      "name": "20240417_174640(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Kliška tvrđava",
  "settings": {
    "mouseViewMode": "qtvr",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
